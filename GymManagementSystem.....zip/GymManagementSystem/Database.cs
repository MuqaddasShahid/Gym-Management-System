﻿using Microsoft.Data.SqlClient;

namespace GymManagementSystem
{
    class Database
    {
        public static SqlConnection GetConnection()
        {
            return new SqlConnection(
                "Server=MUQADDAS\\SQLEXPRESS;Database=GymDB;Trusted_Connection=True;TrustServerCertificate=True;"
            );
        }
    }
}
