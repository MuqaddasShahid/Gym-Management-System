﻿namespace GymManagementSystem
{
    partial class Dashboard
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnMembers = new Button();
            btnTrainers = new Button();
            btnPayments = new Button();
            Logout = new Button();
            btnReports = new Button();
            SuspendLayout();
            // 
            // btnMembers
            // 
            btnMembers.Anchor = AnchorStyles.Top;
            btnMembers.BackColor = Color.DarkOrange;
            btnMembers.FlatStyle = FlatStyle.Flat;
            btnMembers.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnMembers.ForeColor = SystemColors.ButtonHighlight;
            btnMembers.Location = new Point(284, 41);
            btnMembers.Name = "btnMembers";
            btnMembers.Size = new Size(217, 65);
            btnMembers.TabIndex = 0;
            btnMembers.Text = "Members";
            btnMembers.UseVisualStyleBackColor = false;
            btnMembers.Click += btnMembers_Click;
            // 
            // btnTrainers
            // 
            btnTrainers.Anchor = AnchorStyles.Top;
            btnTrainers.BackColor = Color.MediumVioletRed;
            btnTrainers.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnTrainers.ForeColor = SystemColors.ButtonHighlight;
            btnTrainers.Location = new Point(284, 132);
            btnTrainers.Name = "btnTrainers";
            btnTrainers.Size = new Size(217, 57);
            btnTrainers.TabIndex = 1;
            btnTrainers.Text = "Trainers";
            btnTrainers.UseVisualStyleBackColor = false;
            btnTrainers.Click += btnTrainers_Click;
            // 
            // btnPayments
            // 
            btnPayments.Anchor = AnchorStyles.Top;
            btnPayments.BackColor = Color.Navy;
            btnPayments.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPayments.ForeColor = SystemColors.ButtonHighlight;
            btnPayments.Location = new Point(284, 214);
            btnPayments.Name = "btnPayments";
            btnPayments.Size = new Size(217, 65);
            btnPayments.TabIndex = 2;
            btnPayments.Text = "Payments";
            btnPayments.UseVisualStyleBackColor = false;
            btnPayments.Click += btnPayments_Click;
            // 
            // Logout
            // 
            Logout.Anchor = AnchorStyles.Bottom | AnchorStyles.Right;
            Logout.BackColor = Color.DarkRed;
            Logout.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Logout.ForeColor = SystemColors.ButtonHighlight;
            Logout.Location = new Point(604, 376);
            Logout.Name = "Logout";
            Logout.Size = new Size(160, 49);
            Logout.TabIndex = 3;
            Logout.Text = "Logout";
            Logout.UseVisualStyleBackColor = false;
            Logout.Click += Logout_Click;
            // 
            // btnReports
            // 
            btnReports.Anchor = AnchorStyles.Top;
            btnReports.BackColor = Color.WhiteSmoke;
            btnReports.Font = new Font("Segoe UI Semibold", 18F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnReports.Location = new Point(284, 299);
            btnReports.Name = "btnReports";
            btnReports.Size = new Size(217, 53);
            btnReports.TabIndex = 4;
            btnReports.Tag = "";
            btnReports.Text = "Reports";
            btnReports.UseVisualStyleBackColor = false;
            btnReports.Click += btnReports_Click;
            // 
            // Dashboard
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackgroundImage = Properties.Resources.Gym_3;
            BackgroundImageLayout = ImageLayout.Stretch;
            ClientSize = new Size(800, 450);
            Controls.Add(btnReports);
            Controls.Add(Logout);
            Controls.Add(btnPayments);
            Controls.Add(btnTrainers);
            Controls.Add(btnMembers);
            Name = "Dashboard";
            Text = "Dashboard";
            Load += Dashboard_Load;
            ResumeLayout(false);
        }

        #endregion

        private Button btnMembers;
        private Button btnTrainers;
        private Button btnPayments;
        private Button Logout;
        private Button btnReports;
        private Button button1;
    }
}