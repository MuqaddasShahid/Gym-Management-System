﻿namespace GymManagementSystem
{
    partial class ReportsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dataGridView1 = new DataGridView();
            btnLoad = new Button();
            btnPrint = new Button();
            comboReport = new ComboBox();
            label2 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.BackgroundColor = SystemColors.GradientActiveCaption;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(12, 217);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(784, 221);
            dataGridView1.TabIndex = 0;
            // 
            // btnLoad
            // 
            btnLoad.BackColor = Color.DarkSalmon;
            btnLoad.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnLoad.Location = new Point(449, 148);
            btnLoad.Name = "btnLoad";
            btnLoad.Size = new Size(153, 52);
            btnLoad.TabIndex = 1;
            btnLoad.Text = "Load Reports";
            btnLoad.UseVisualStyleBackColor = false;
            btnLoad.Click += btnLoad_Click;
            // 
            // btnPrint
            // 
            btnPrint.BackColor = Color.RosyBrown;
            btnPrint.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnPrint.Location = new Point(635, 146);
            btnPrint.Name = "btnPrint";
            btnPrint.Size = new Size(153, 54);
            btnPrint.TabIndex = 2;
            btnPrint.Text = "Print Reports";
            btnPrint.UseVisualStyleBackColor = false;
            btnPrint.Click += btnPrint_Click;
            // 
            // comboReport
            // 
            comboReport.BackColor = Color.AntiqueWhite;
            comboReport.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboReport.FormattingEnabled = true;
            comboReport.Items.AddRange(new object[] { "Members", "Trainers", "Payments" });
            comboReport.Location = new Point(264, 53);
            comboReport.Name = "comboReport";
            comboReport.Size = new Size(203, 39);
            comboReport.TabIndex = 3;
            comboReport.SelectedIndexChanged += comboReports_SelectedIndexChanged;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.BackColor = Color.Bisque;
            label2.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(58, 53);
            label2.Name = "label2";
            label2.Size = new Size(168, 31);
            label2.TabIndex = 5;
            label2.Text = "Choose Report";
            // 
            // ReportsForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label2);
            Controls.Add(comboReport);
            Controls.Add(btnPrint);
            Controls.Add(btnLoad);
            Controls.Add(dataGridView1);
            Name = "ReportsForm";
            Text = "ReportsForm";
            Load += ReportsForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private DataGridView dataGridView1;
        private Button btnLoad;
        private Button btnPrint;
        private ComboBox comboReport;
        private Label label2;
    }
}