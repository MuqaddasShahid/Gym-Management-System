﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace GymManagementSystem
{
    public partial class PaymentsForm : Form
    {
        public PaymentsForm()
        {
            InitializeComponent();
        }

        private void PaymentsForm_Load(object sender, EventArgs e)
        {
            LoadMembers();
            LoadData();
        }
        void LoadMembers()
        {
            using (SqlConnection con = Database.GetConnection())
            {
                SqlDataAdapter da =
                    new SqlDataAdapter("SELECT MemberID, Name FROM Members", con);

                DataTable dt = new DataTable();
                da.Fill(dt);

                comboMember.DataSource = dt;
                comboMember.DisplayMember = "Name";
                comboMember.ValueMember = "MemberID";
            }
        }
        void LoadData()
        {
            using (SqlConnection con = Database.GetConnection())
            {
                SqlDataAdapter da =
                    new SqlDataAdapter("SELECT * FROM Payments", con);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dataGridView1.DataSource = dt;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = Database.GetConnection())
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Payments(MemberID,Amount,PaymentDate,Status) VALUES(@m,@a,@d,@s)", con);

                cmd.Parameters.AddWithValue("@m", comboMember.SelectedValue);
                cmd.Parameters.AddWithValue("@a", txtAmount.Text);
                cmd.Parameters.AddWithValue("@d", dateTimePicker1.Value);
                cmd.Parameters.AddWithValue("@s", txtStatus.Text);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Payment Added");

            LoadData();

        }
        void ClearFields()
        {
            txtAmount.Clear();
            txtStatus.Clear();
            comboMember.SelectedIndex = 0;
        }

        private void dateTimePicker1_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
