﻿namespace GymManagementSystem
{
    partial class PaymentsForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            comboMember = new ComboBox();
            txtAmount = new TextBox();
            dateTimePicker1 = new DateTimePicker();
            txtStatus = new TextBox();
            btnAdd = new Button();
            dataGridView1 = new DataGridView();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // comboMember
            // 
            comboMember.BackColor = Color.LightCoral;
            comboMember.DisplayMember = "Name";
            comboMember.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            comboMember.FormattingEnabled = true;
            comboMember.Location = new Point(227, 12);
            comboMember.Name = "comboMember";
            comboMember.Size = new Size(197, 36);
            comboMember.TabIndex = 0;
            comboMember.ValueMember = "Member ID";
            // 
            // txtAmount
            // 
            txtAmount.BackColor = Color.Salmon;
            txtAmount.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtAmount.Location = new Point(227, 64);
            txtAmount.Name = "txtAmount";
            txtAmount.Size = new Size(197, 34);
            txtAmount.TabIndex = 1;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.CalendarForeColor = SystemColors.ControlLight;
            dateTimePicker1.CalendarTitleBackColor = SystemColors.GradientActiveCaption;
            dateTimePicker1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            dateTimePicker1.Location = new Point(227, 165);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(349, 34);
            dateTimePicker1.TabIndex = 2;
            dateTimePicker1.ValueChanged += dateTimePicker1_ValueChanged;
            // 
            // txtStatus
            // 
            txtStatus.BackColor = Color.DarkSalmon;
            txtStatus.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtStatus.Location = new Point(227, 113);
            txtStatus.Name = "txtStatus";
            txtStatus.Size = new Size(197, 34);
            txtStatus.TabIndex = 3;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.Navy;
            btnAdd.FlatStyle = FlatStyle.Flat;
            btnAdd.ForeColor = SystemColors.ButtonHighlight;
            btnAdd.Location = new Point(576, 221);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(212, 45);
            btnAdd.TabIndex = 4;
            btnAdd.Text = "Add Payment";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.BackgroundColor = SystemColors.GradientActiveCaption;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(0, 278);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(800, 172);
            dataGridView1.TabIndex = 5;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(29, 15);
            label1.Name = "label1";
            label1.Size = new Size(149, 28);
            label1.TabIndex = 6;
            label1.Text = "Select Member";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(41, 70);
            label2.Name = "label2";
            label2.Size = new Size(86, 28);
            label2.TabIndex = 7;
            label2.Text = "Amount";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(48, 119);
            label3.Name = "label3";
            label3.Size = new Size(67, 28);
            label3.TabIndex = 8;
            label3.Text = "Status";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label4.Location = new Point(41, 171);
            label4.Name = "label4";
            label4.Size = new Size(108, 28);
            label4.TabIndex = 9;
            label4.Text = "Date / Day";
            // 
            // PaymentsForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label4);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(dataGridView1);
            Controls.Add(btnAdd);
            Controls.Add(txtStatus);
            Controls.Add(dateTimePicker1);
            Controls.Add(txtAmount);
            Controls.Add(comboMember);
            Name = "PaymentsForm";
            Text = "PaymentsForm";
            Load += PaymentsForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private ComboBox comboMember;
        private TextBox txtAmount;
        private DateTimePicker dateTimePicker1;
        private TextBox txtStatus;
        private Button btnAdd;
        private DataGridView dataGridView1;
        private Label label1;
        private Label label2;
        private Label label3;
        private Label label4;
    }
}