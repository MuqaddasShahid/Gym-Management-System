﻿using Microsoft.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Drawing.Printing;
using System.Text;
using System.Windows.Forms;
namespace GymManagementSystem
{
    public partial class ReportsForm : Form
    {
        Bitmap? bmp;
        public ReportsForm()
        {
            InitializeComponent();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            SqlConnection con = Database.GetConnection();

            string query = "";

            if (comboReport.Text == "Members")
            {
                query = "SELECT * FROM Members";
            }
            else if (comboReport.Text == "Trainers")
            {
                query = "SELECT * FROM Trainers";
            }
            else if (comboReport.Text == "Payments")
            {
                query = @"SELECT Payments.PaymentID,
                         ISNULL(Members.Name,'Deleted Member') AS Name,
                         Payments.Amount,
                         Payments.PaymentDate,
                         Payments.Status
                  FROM Payments
                  LEFT JOIN Members
                  ON Payments.MemberID = Members.MemberID";
            }

            SqlDataAdapter da = new SqlDataAdapter(query, con);

            DataTable dt = new DataTable();

            da.Fill(dt);

            dataGridView1.DataSource = dt;



        }

        private void ReportsForm_Load(object sender, EventArgs e)
        {
            comboReport.SelectedIndex = 0;
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            int height = dataGridView1.Height;

            dataGridView1.Height =
                dataGridView1.RowCount * dataGridView1.RowTemplate.Height * 2;

            bmp = new Bitmap(dataGridView1.Width, dataGridView1.Height);

            dataGridView1.DrawToBitmap(
                bmp,
                new Rectangle(0, 0,
                dataGridView1.Width,
                dataGridView1.Height));

            dataGridView1.Height = height;

            PrintDocument pd = new PrintDocument();

            pd.PrintPage += new PrintPageEventHandler(Pd_PrintPage);

            PrintPreviewDialog preview = new PrintPreviewDialog();

            preview.Document = pd;

            preview.ShowDialog();


        }
        private void Pd_PrintPage(object sender, PrintPageEventArgs e)
        {
            if (bmp != null && e.Graphics != null)
            {
                e.Graphics.DrawImage(bmp, 0, 0);
            }
        }

        private void comboReports_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
