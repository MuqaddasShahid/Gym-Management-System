﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace GymManagementSystem
{
    public partial class TrainersForm : Form
    {
        public TrainersForm()
        {
            InitializeComponent();
        }
        void LoadData()
        {
            using (SqlConnection con = Database.GetConnection())
            {
                SqlDataAdapter da =
                    new SqlDataAdapter("SELECT * FROM Trainers", con);

                DataTable dt = new DataTable();

                da.Fill(dt);

                dataGridView1.DataSource = dt;
            }
        }
        void ClearFields()
        {
            txtName.Clear();
            txtPhone.Clear();
            txtSpeciality.Clear();
            txtID.Clear();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = Database.GetConnection())
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    "INSERT INTO Trainers(Name,Phone,Speciality) VALUES(@n,@p,@s)", con);

                cmd.Parameters.AddWithValue("@n", txtName.Text);
                cmd.Parameters.AddWithValue("@p", txtPhone.Text);
                cmd.Parameters.AddWithValue("@s", txtSpeciality.Text);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Trainer Added");

            LoadData();

            ClearFields();
        }

        private void TrainersForm_Load(object sender, EventArgs e)
        {

            txtID.Visible = false;

            LoadData();

            dataGridView1.AutoSizeColumnsMode =
                DataGridViewAutoSizeColumnsMode.Fill;

            dataGridView1.SelectionMode =
                DataGridViewSelectionMode.FullRowSelect;

            dataGridView1.MultiSelect = false;
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row =
                    dataGridView1.Rows[e.RowIndex];

                txtID.Text =
                    row.Cells["TrainerID"].Value?.ToString();

                txtName.Text =
                    row.Cells["Name"].Value?.ToString();

                txtPhone.Text =
                    row.Cells["Phone"].Value?.ToString();

                txtSpeciality.Text =
                    row.Cells["Speciality"].Value?.ToString();
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = Database.GetConnection())
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    "UPDATE Trainers SET Name=@n, Phone=@p, Speciality=@s WHERE TrainerID=@id",
                    con);

                cmd.Parameters.AddWithValue("@n", txtName.Text);
                cmd.Parameters.AddWithValue("@p", txtPhone.Text);
                cmd.Parameters.AddWithValue("@s", txtSpeciality.Text);
                cmd.Parameters.AddWithValue("@id", txtID.Text);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Trainer Updated");

            LoadData();

            ClearFields();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = Database.GetConnection())
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    "DELETE FROM Trainers WHERE TrainerID=@id", con);

                cmd.Parameters.AddWithValue("@id", txtID.Text);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Trainer Deleted");

            LoadData();

            ClearFields();
        }
    }
}

