﻿namespace GymManagementSystem
{
    partial class MembersForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtName = new TextBox();
            txtPhone = new TextBox();
            txtType = new TextBox();
            txtID = new TextBox();
            dataGridView1 = new DataGridView();
            btnAdd = new Button();
            btnUpdate = new Button();
            btnDelete = new Button();
            cmbTrainer = new ComboBox();
            label4 = new Label();
            dtpStartDate = new DateTimePicker();
            dtpExpiryDate = new DateTimePicker();
            label5 = new Label();
            label6 = new Label();
            ((System.ComponentModel.ISupportInitialize)dataGridView1).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BackColor = Color.White;
            label1.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label1.Location = new Point(75, 26);
            label1.Margin = new Padding(5, 0, 5, 0);
            label1.Name = "label1";
            label1.Size = new Size(76, 31);
            label1.TabIndex = 0;
            label1.Text = "Name";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label2.Location = new Point(75, 108);
            label2.Margin = new Padding(5, 0, 5, 0);
            label2.Name = "label2";
            label2.Size = new Size(79, 31);
            label2.TabIndex = 1;
            label2.Text = "Phone";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            label3.Location = new Point(75, 205);
            label3.Margin = new Padding(5, 0, 5, 0);
            label3.Name = "label3";
            label3.Size = new Size(201, 31);
            label3.TabIndex = 2;
            label3.Text = "Membership Type";
            label3.Click += label3_Click;
            // 
            // txtName
            // 
            txtName.BackColor = SystemColors.GradientActiveCaption;
            txtName.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtName.Location = new Point(294, 26);
            txtName.Margin = new Padding(5, 5, 5, 5);
            txtName.Name = "txtName";
            txtName.Size = new Size(319, 38);
            txtName.TabIndex = 4;
            // 
            // txtPhone
            // 
            txtPhone.BackColor = SystemColors.GradientActiveCaption;
            txtPhone.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtPhone.Location = new Point(294, 108);
            txtPhone.Margin = new Padding(5, 5, 5, 5);
            txtPhone.Name = "txtPhone";
            txtPhone.Size = new Size(319, 38);
            txtPhone.TabIndex = 5;
            // 
            // txtType
            // 
            txtType.BackColor = SystemColors.GradientActiveCaption;
            txtType.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            txtType.Location = new Point(294, 205);
            txtType.Margin = new Padding(5, 5, 5, 5);
            txtType.Name = "txtType";
            txtType.Size = new Size(319, 38);
            txtType.TabIndex = 6;
            // 
            // txtID
            // 
            txtID.Location = new Point(294, 309);
            txtID.Margin = new Padding(5, 5, 5, 5);
            txtID.Name = "txtID";
            txtID.Size = new Size(319, 38);
            txtID.TabIndex = 7;
            txtID.Visible = false;
            // 
            // dataGridView1
            // 
            dataGridView1.Anchor = AnchorStyles.Top | AnchorStyles.Bottom | AnchorStyles.Left | AnchorStyles.Right;
            dataGridView1.BackgroundColor = SystemColors.ActiveCaption;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.Location = new Point(0, 477);
            dataGridView1.Margin = new Padding(5, 5, 5, 5);
            dataGridView1.Name = "dataGridView1";
            dataGridView1.RowHeadersWidth = 51;
            dataGridView1.Size = new Size(1300, 220);
            dataGridView1.TabIndex = 8;
            dataGridView1.CellContentClick += dataGridView1_CellContentClick;
            // 
            // btnAdd
            // 
            btnAdd.BackColor = Color.FromArgb(192, 255, 255);
            btnAdd.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnAdd.Location = new Point(699, 387);
            btnAdd.Margin = new Padding(5, 5, 5, 5);
            btnAdd.Name = "btnAdd";
            btnAdd.Size = new Size(153, 74);
            btnAdd.TabIndex = 9;
            btnAdd.Text = "ADD";
            btnAdd.UseVisualStyleBackColor = false;
            btnAdd.Click += btnAdd_Click;
            // 
            // btnUpdate
            // 
            btnUpdate.BackColor = Color.FromArgb(255, 255, 192);
            btnUpdate.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnUpdate.Location = new Point(911, 390);
            btnUpdate.Margin = new Padding(5, 5, 5, 5);
            btnUpdate.Name = "btnUpdate";
            btnUpdate.Size = new Size(153, 71);
            btnUpdate.TabIndex = 10;
            btnUpdate.Text = "UPDATE";
            btnUpdate.UseVisualStyleBackColor = false;
            btnUpdate.Click += btnUpdate_Click;
            // 
            // btnDelete
            // 
            btnDelete.BackColor = Color.IndianRed;
            btnDelete.Font = new Font("Segoe UI Semibold", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btnDelete.Location = new Point(1125, 387);
            btnDelete.Margin = new Padding(5, 5, 5, 5);
            btnDelete.Name = "btnDelete";
            btnDelete.Size = new Size(153, 71);
            btnDelete.TabIndex = 11;
            btnDelete.Text = "DELETE";
            btnDelete.UseVisualStyleBackColor = false;
            btnDelete.Click += btnDelete_Click;
            // 
            // cmbTrainer
            // 
            cmbTrainer.BackColor = SystemColors.GradientActiveCaption;
            cmbTrainer.FormattingEnabled = true;
            cmbTrainer.Location = new Point(959, 23);
            cmbTrainer.Margin = new Padding(5, 5, 5, 5);
            cmbTrainer.Name = "cmbTrainer";
            cmbTrainer.Size = new Size(319, 39);
            cmbTrainer.TabIndex = 12;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(747, 29);
            label4.Margin = new Padding(5, 0, 5, 0);
            label4.Name = "label4";
            label4.Size = new Size(154, 31);
            label4.TabIndex = 13;
            label4.Text = "Select Trainer";
            // 
            // dtpStartDate
            // 
            dtpStartDate.Location = new Point(959, 108);
            dtpStartDate.Name = "dtpStartDate";
            dtpStartDate.Size = new Size(319, 38);
            dtpStartDate.TabIndex = 14;
            // 
            // dtpExpiryDate
            // 
            dtpExpiryDate.Location = new Point(959, 205);
            dtpExpiryDate.Name = "dtpExpiryDate";
            dtpExpiryDate.Size = new Size(319, 38);
            dtpExpiryDate.TabIndex = 15;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold | FontStyle.Italic, GraphicsUnit.Point, 0);
            label5.Location = new Point(756, 115);
            label5.Name = "label5";
            label5.Size = new Size(120, 31);
            label5.TabIndex = 16;
            label5.Text = "Start Date";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(756, 212);
            label6.Name = "label6";
            label6.Size = new Size(135, 31);
            label6.TabIndex = 17;
            label6.Text = "Expiry Date";
            // 
            // MembersForm
            // 
            AutoScaleDimensions = new SizeF(13F, 31F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1300, 698);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(dtpExpiryDate);
            Controls.Add(dtpStartDate);
            Controls.Add(label4);
            Controls.Add(cmbTrainer);
            Controls.Add(btnDelete);
            Controls.Add(btnUpdate);
            Controls.Add(btnAdd);
            Controls.Add(dataGridView1);
            Controls.Add(txtID);
            Controls.Add(txtType);
            Controls.Add(txtPhone);
            Controls.Add(txtName);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI Semibold", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            Margin = new Padding(5, 5, 5, 5);
            Name = "MembersForm";
            Text = "MembersForm";
            Load += MembersForm_Load;
            ((System.ComponentModel.ISupportInitialize)dataGridView1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtName;
        private TextBox txtPhone;
        private TextBox txtType;
        private TextBox txtID;
        private DataGridView dataGridView1;
        private Button btnAdd;
        private Button btnUpdate;
        private Button btnDelete;
        private ComboBox cmbTrainer;
        private Label label4;
        private DateTimePicker dtpStartDate;
        private DateTimePicker dtpExpiryDate;
        private Label label5;
        private Label label6;
    }
}