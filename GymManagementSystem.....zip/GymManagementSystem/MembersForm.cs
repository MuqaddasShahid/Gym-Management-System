﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
namespace GymManagementSystem
{
    public partial class MembersForm : Form
    {
        public MembersForm()
        {
            InitializeComponent();
        }
        void LoadData()
        {
            using (SqlConnection con = Database.GetConnection())
            {
                SqlDataAdapter da =
                    new SqlDataAdapter("SELECT * FROM Members", con);

                DataTable dt = new DataTable();

                da.Fill(dt);

                dataGridView1.DataSource = dt;
            }

        }
        void ClearFields()
        {
            txtName.Clear();
            txtPhone.Clear();
            txtType.Clear();
            txtID.Clear();
        }
        private void MembersForm_Load(object sender, EventArgs e)
        {
            LoadTrainers();
            LoadData();
            txtID.Visible = false;
        }
        void LoadTrainers()
{
    try
    {
        using (SqlConnection con = Database.GetConnection())
        {
            con.Open();

            SqlDataAdapter da =
                new SqlDataAdapter(
                    "SELECT TrainerID, Name FROM Trainers", con);

            DataTable dt = new DataTable();
            da.Fill(dt);

            if (dt.Rows.Count > 0)
            {
                cmbTrainer.DataSource = dt;
                cmbTrainer.DisplayMember = "Name";
                cmbTrainer.ValueMember = "TrainerID";
            }
            else
            {
                MessageBox.Show("No trainers found in database");
            }
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show("Error: " + ex.Message);
    }
}


        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtName.Text == "" || txtPhone.Text == "" || txtType.Text == "")
            {
                MessageBox.Show("Please fill all fields");
                return;
            }
            using (SqlConnection con = Database.GetConnection())
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                          "INSERT INTO Members(Name,Phone,TrainerID,MembershipType,StartDate,ExpiryDate) VALUES(@n,@p,@t,@m,@s,@e)", con);


                cmd.Parameters.AddWithValue("@n", txtName.Text);
                cmd.Parameters.AddWithValue("@p", txtPhone.Text);
                cmd.Parameters.AddWithValue("@t", cmbTrainer.SelectedValue);
                cmd.Parameters.AddWithValue("@m", txtType.Text);
                cmd.Parameters.AddWithValue("@s", dtpStartDate.Value);
                cmd.Parameters.AddWithValue("@e", dtpExpiryDate.Value);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Member Added");

            LoadData();

            ClearFields();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow row =
                    dataGridView1.Rows[e.RowIndex];

                txtID.Text = row.Cells["MemberID"].Value?.ToString();
                txtName.Text = row.Cells["Name"].Value?.ToString();
                txtPhone.Text = row.Cells["Phone"].Value?.ToString();
                txtType.Text = row.Cells["MembershipType"].Value?.ToString();
                // TrainerID Safe Check
                if (row.Cells["TrainerID"].Value != DBNull.Value)
                {
                    cmbTrainer.SelectedValue =
                        Convert.ToInt32(row.Cells["TrainerID"].Value);
                }
                else
                {
                    cmbTrainer.SelectedIndex = -1;
                }

                // StartDate Safe Check
                if (row.Cells["StartDate"].Value != DBNull.Value)
                {
                    dtpStartDate.Value =
                        Convert.ToDateTime(row.Cells["StartDate"].Value);
                }

                // ExpiryDate Safe Check
                if (row.Cells["ExpiryDate"].Value != DBNull.Value)
                {
                    dtpExpiryDate.Value =
                        Convert.ToDateTime(row.Cells["ExpiryDate"].Value);
                }
            
        }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (txtID.Text == "")
            {
                MessageBox.Show("Please select a member first");
                return;
            }

            if (txtName.Text == "" || txtPhone.Text == "" || txtType.Text == "")
            {
                MessageBox.Show("Please fill all fields");
                return;
            }

            using (SqlConnection con = Database.GetConnection())
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    "UPDATE Members SET Name=@n, Phone=@p, TrainerID=@t, MembershipType=@m, StartDate=@s, ExpiryDate=@e WHERE MemberID=@id",
                    con);

                cmd.Parameters.AddWithValue("@n", txtName.Text);
                cmd.Parameters.AddWithValue("@p", txtPhone.Text);
                cmd.Parameters.AddWithValue("@t", cmbTrainer.SelectedValue ?? (object)DBNull.Value);
                cmd.Parameters.AddWithValue("@m", txtType.Text);
                cmd.Parameters.AddWithValue("@s", dtpStartDate.Value);
                cmd.Parameters.AddWithValue("@e", dtpExpiryDate.Value);
                cmd.Parameters.AddWithValue("@id", Convert.ToInt32(txtID.Text));

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Member Updated");

            LoadData();

            ClearFields();
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            using (SqlConnection con = Database.GetConnection())
            {
                con.Open();

                SqlCommand cmd = new SqlCommand(
                    "DELETE FROM Members WHERE MemberID=@id", con);

                cmd.Parameters.AddWithValue("@id", txtID.Text);

                cmd.ExecuteNonQuery();
            }

            MessageBox.Show("Member Deleted");

            LoadData();

            ClearFields();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }
    }
}
