﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace GymManagementSystem
{
    public partial class Dashboard : Form
    {
        public Dashboard()
        {
            InitializeComponent();
            this.DoubleBuffered = true;
        }

        private void btnMembers_Click(object sender, EventArgs e)
        {
            MembersForm m = new MembersForm();
            m.Show();
            btnMembers.FlatStyle = FlatStyle.Flat;
            btnMembers.BackColor = Color.DarkBlue;
            btnMembers.ForeColor = Color.White;
        }

        private void btnTrainers_Click(object sender, EventArgs e)
        {
            TrainersForm t = new TrainersForm();
            t.Show();
        }

        private void btnPayments_Click(object sender, EventArgs e)
        {
            PaymentsForm p = new PaymentsForm();
            p.Show();
        }

        private void Dashboard_Load(object sender, EventArgs e)
        {
            btnMembers.FlatStyle = FlatStyle.Flat;
            btnTrainers.FlatStyle = FlatStyle.Flat;
            btnPayments.FlatStyle = FlatStyle.Flat;
        }

        private void Logout_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show(
      "Are you sure you want to logout?",
      "Logout",
      MessageBoxButtons.YesNo,
      MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                LoginForm login = new LoginForm();
                login.Show();

                this.Hide();
            }
        }

        private void btnReports_Click(object sender, EventArgs e)
        {
            ReportsForm r = new ReportsForm();
            r.Show();
        }
    }
}
